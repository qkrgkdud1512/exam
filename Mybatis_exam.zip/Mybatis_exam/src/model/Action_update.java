package model;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import model.Action_update;
import mybatis.Map;

public class Action_update {
	static Action_update up = new Action_update();
	public static Action_update instance(){
		return up;
}
	private SqlSessionFactory factory = Map.getSqlSession(); //Map.java 파일을 찾아옴
	
	public void userupdate(String id, String pw){

		
		Dto dto = new Dto();
		dto.setId(id);
		dto.setPw(pw);
		
		
		
		System.out.println(id+pw);
		SqlSession sqlSession = factory.openSession();
		sqlSession.update("update_user",dto);//mapper에서 지정한 id 넣어주기
	    sqlSession.commit();
		sqlSession.close();
		
	}
}