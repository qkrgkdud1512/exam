package model;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import model.Action_delete;
import mybatis.Map;

public class Action_delete {
	static Action_delete del = new Action_delete();
	public static Action_delete instance(){
		return del;
}
		
private SqlSessionFactory factory = Map.getSqlSession(); //Map.java 파일을 찾아옴
	
	public void userdelete(String id){		
		Dto dto = new Dto();
		dto.setId(id);
		
		System.out.println(id);
		SqlSession sqlSession = factory.openSession();
		sqlSession.delete("delete_user",dto);//mapper에서 지정한 id 넣어주기
		System.out.println(dto.id);
	    sqlSession.commit();
		sqlSession.close();
			
		}	
	}
