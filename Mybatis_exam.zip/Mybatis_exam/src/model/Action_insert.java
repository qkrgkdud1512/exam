package model;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import model.Action_insert;
import mybatis.Map;

public class Action_insert {
	static Action_insert in = new Action_insert();
	public static Action_insert instance(){
		return in;
}
	private SqlSessionFactory factory = Map.getSqlSession(); //Map.java 파일을 찾아옴
	
	public void userinsert(String id, String name, String pw){

		
		Dto dto = new Dto();
		dto.setId(id);
		dto.setName(name);
		dto.setPw(pw);
		
		
		
		
		SqlSession sqlSession = factory.openSession();
		sqlSession.insert("insert_user",dto);//mapper에서 지정한 id 넣어주기
	    sqlSession.commit();
		sqlSession.close();
		
	}
}