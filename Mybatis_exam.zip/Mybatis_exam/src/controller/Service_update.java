package controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import model.Action_update;
import model.Dto;

public class Service_update implements Cominterface{
	
	static Service_update up = new Service_update();
	public static Service_update instance() {
		return up;
	}


	@Override
	public String showData(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		System.out.println(id+pw);
		Action_update up = Action_update.instance(); //싱글톤 객체
		up.userupdate(id, pw);
		return "updateok.jsp";
	}

}
