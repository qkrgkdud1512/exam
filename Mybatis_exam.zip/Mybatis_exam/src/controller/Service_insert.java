package controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import model.Action_insert;
import model.Dto;

public class Service_insert implements Cominterface{
	
	static Service_insert in = new Service_insert();
	public static Service_insert instance() {
		return in;
	}


	@Override
	public String showData(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String pw = request.getParameter("pw");
		
		Action_insert in = Action_insert.instance(); //싱글톤 객체
		in.userinsert(id,name,pw);
		
		return "insertok.jsp";
	}

}
