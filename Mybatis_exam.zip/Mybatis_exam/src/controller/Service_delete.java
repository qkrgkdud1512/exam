package controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Action_delete;
import model.Dto;

public class Service_delete implements Cominterface{
	
	static Service_delete del = new Service_delete();
	public static Service_delete instance() {
		return del;
	}
	@Override
	public String showData(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String id = request.getParameter("id");
		

		System.out.println(id);
		Action_delete del = Action_delete.instance(); //싱글톤 객체
		del.userdelete(id);
		
		return "deleteok.jsp";
	}


	
	

}
